import pandas as pd
import gmplot
from geopy.distance import VincentyDistance
import geopy
import math
df = pd.read_csv(r"df_sensors2.csv")
seconds = len(df['seconds'])
velocity = []
dis = []
azi = []
lat = [30.87847329]
long = [29.580237]
Azimuth = df['Azimuth'][0]
v = 0.0
d = 0.0
t = 4.746289895
counter = 0
for i in range(seconds):
    if counter == 40:
        velocity.append(v)
        dis.append(d)
        azi.append((Azimuth / counter))
        counter = 0
        v = 0
        d = 0
        Azimuth = float(df['Azimuth'][i])
    ax = float(df['Accelerator_x'][i])**2
    ay = float(df['Accelerator_y'][i])**2
    az = float(df['Accelerator_z'][i])**2
    v_mag = math.sqrt((ax+ay+az))
    dt = (float(df['seconds'][i]-t))
    v = v+(v_mag*dt)
    d = d + (v * dt) + (0.5 * v_mag * dt * dt)
    t = float(df['seconds'][i])
    Azimuth = Azimuth + float(df['Azimuth'][i])
    counter = counter+1

for k in range(len(dis)):
    origin = geopy.Point(lat[k], long[k])
    new = VincentyDistance(meters=(dis[k])).destination(origin, azi[k])
    lat.append(new.latitude)
    long.append(new.longitude)

gmap = gmplot.GoogleMapPlotter(lat[0], long[0], 16)
gmap.polygon(lat, long, '#FF6666', edge_width=10)
gmap.draw('map2.html')





